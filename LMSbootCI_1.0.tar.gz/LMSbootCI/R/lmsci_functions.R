

#' Report distribution parameters of a gamlss model depending on 'new' x-values
#'
#' @export
#' @author  Peter Dilba
#' @name    Distribution Parameters Reporting Function
#' @title   parameters
#'
#' @param obj   gamlss object
#' @param ...   further arguments to be passed
#' @return    table of distribution parameters of a fitted LMS model, for given x values
#'


parameters <- function(obj, ...) UseMethod("parameters")






#' Report distribution parameters of a gamlss model depending on 'new' x-values
#'
#' Note that a valid gamlss object with only one covariable has to be passed.
#'
#' @export
#' @author  Peter Dilba
#' @name    Distribution Parameters Reporting Function
#' @title   parameters.gamlss
#'
#' @param obj   a gamlss object with only one covariate
#' @param data   data of the original fitted model
#' @param xname	  character, the name of the unique explanatory variable (it has to be the same as in the original fitted model)
#' @param xvalues   the new values for the explanatory variable where the prediction will take place
#' @return    table of distribution parameters of a fitted LMS model, for given x values
#'


parameters.gamlss <- function(obj, data = NULL, xname, xvalues, ...)
{
	data.name <- unlist(strsplit(unlist(strsplit(unlist(strsplit(
		gsub(" ", "", paste(deparse(obj$call), collapse="")), "data="))[2], ")")), ","))[1]
	if(!exists(data.name)){
		if(is.null(data)) stop("Data of the fitted model are not present.\n Please assign it using 'data ='.\n")
	}
	newx.df <- data.frame(x = xvalues)
	colnames(newx.df)[1] <- xname
	new.fit <- predictAll(obj, newdata = newx.df, data = data)
	res <- cbind(newx.df[,1], as.data.frame(new.fit))	
	colnames(res)[1] <- xname
	return(res)
}



#' Report quantiles depending on 'new' x-values
#'
#' @export
#' @author  Peter Dilba
#' @name    Quantile Reporting Function
#' @title   cont_quantiles
#'
#' @param obj   a gamlss object with only one covariate
#' @param ...   further arguments to be passed
#' @return    table of quantiles of a fitted LMS model, for given x values
#'

cont_quantiles <- function(obj, ...) UseMethod("cont_quantiles")


#' Report quantiles of a gamlss model depending on 'new' x-values
#'
#' @export
#' @author  Peter Dilba
#' @name    Quantile Reporting Function
#' @title   cont_quantiles.gamlss
#'
#' @param obj   a gamlss object with only one covariate
#' @param data   data of the original fitted model
#' @param xname	  character, the name of the unique explanatory variable (it has to be the same as in the original fitted model)
#' @param xvalues   the new values for the explanatory variable where the prediction will take place
#' @param p   percentiles to be calculated
#' @return    table of quantiles of a fitted LMS model, for given x values
#'


cont_quantiles.gamlss <- function(obj, data = NULL, xname, xvalues, p = c(.025, .975), ...)
{	
	data.name <- unlist(strsplit(unlist(strsplit(unlist(strsplit(
		gsub(" ", "", paste(deparse(obj$call), collapse="")), "data="))[2], ")")), ","))[1]
	if(!exists(data.name)){
		if(is.null(data)) stop("Data of the fitted model are not present.\n Please assign it using 'data ='.\n")
	}
	qu.out <- NULL
	distr <- obj$family[1]
	parms <- obj$parameters
	newd <- data.frame(x = xvalues)
	colnames(newd) <- xname
	pred <- predictAll(obj, type = "response", newdata = newd, data = data)
	for(i in seq_along(p)){	
		qu.out <- cbind(qu.out,
			eval(parse(text = paste("q", distr, "(p = ", p[i], ",",
				paste(paste(parms, " = pred$", parms, sep = ""), collapse = ","),")", sep = ""))))
	}
	res <- as.data.frame(cbind(newd, qu.out))
	colnames(res)[1] <- xname
	colnames(res)[-1] <- paste("P", round(100*p, 1), sep = "")
	return(res)
}



#' Report quantiles and according bootstrap confidence intervals depending on 'new' x-values
#'
#' @export
#' @author  Peter Dilba
#' @name    Quantile Reporting Function
#' @title   cont_quantiles_ci
#'
#' @param obj   a gamlss object with only one covariate
#' @param ...   further arguments to be passed
#' @return    a list with tables with of quantiles and CIs of a fitted LMS model, for given x values and a table with resampling results
#'

cont_quantiles_ci <- function(obj, ...) UseMethod("cont_quantiles_ci")




#' Report quantiles and according bootstrap confidence intervals of a gamlss model depending on 'new' x-values
#'
#' @export
#' @author  Peter Dilba
#' @name    Quantile Reporting Function
#' @title   cont_quantiles_ci.gamlss
#'
#' @param obj   a gamlss object with only one covariate
#' @param data   data of the original model
#' @param xname   the name of the unique explanatory variable (it has to be the same as in the original fitted model)
#' @param xvalues   the new values for the explanatory variable where the prediction will take place
#' @param p   percentiles to be calculated
#' @param qtype   quantile type according to quantile() function
#' @param cils   limits for the confindence intervals (as percentiles)
#' @param nr   number of bootstrap resamples
#' @param seed   initial seed for resampling
#' @param obj.out   T/F, should all nr fitted gamlss objects be returend too?    note: this could cause problems with your memory size (=> default = F)
#' @param print.dur   T/F, should duration of calculation be returned?
#' @param parallel   T/F, should calculation be performed in parallel on several cores?
#' @param status.freq   only if parallel = F, frequency to return number of finished bootstrap replicates
#' @param n.core   only if parallel = T, number of corse to use for calculation
#' @param max.iter   maximum number of algorithm iterations within each bootstrap gamlss call
#' @param trace   T/F, should iteration info be printed within each bootstrap gamlss call?
#' @return    a list with tables with of quantiles and CIs of a fitted LMS model, for given x values and a table with resampling results
#'

cont_quantiles_ci.gamlss <- function(obj, data = NULL, xname, xvalues, p = c(.025, .5, .975), qtype = 2, cils = c(.025, .975), 
		nr = 999, seed = 1860, obj.out = FALSE, print.dur = TRUE, parallel = FALSE, status.freq = NULL, n.core = 2, max.iter = NULL, trace = NULL, ...)
{
	t0 <- Sys.time()
	quind <- seq_along(p)		
	n <- nrow(data)	
	all.objs <- NULL
	rqu <- list()
	orig.call <- call("gamlss")
	orig.call$formula <- obj$mu.terms
	orig.call$sigma.formula <- obj$sigma.terms
	orig.call$nu.formula <- obj$nu.terms
	orig.call$tau.formula <- obj$tau.terms
	orig.call$family <- obj$family
	orig.call$data <- substitute(data)
	orig.call$control <- gamlss.control(n.cyc = obj$control$n.cyc, trace = obj$control$trace)
	orig.obj <- eval(orig.call)	
	# resampling loop
	if(parallel){	
		status.freq <- NULL
		n.core <- min(c(n.core, detectCores()/2))
		seed1 <- seed
		seed2 <- seed+nr-1
		clus <- makeCluster(n.core)
#		clusterExport(cl = clus, expr = library(gamlss))
		clusterExport(cl = clus, varlist = c('inner.boot.ci.gamlss', 'wh'))
		erg <- clusterApplyLB(cl = clus, x = seed1:seed2, fun = inner.boot.ci.gamlss,
				data = data, n = n, orig.obj = orig.obj, xname = xname, xvalues = xvalues, p = p)
		stopCluster(cl = clus)
		id.ok <- sapply(erg, function(x)ifelse(any(sapply(x, class) %in% "try-error"), F, T))
		all.objs.ok <- erg[id.ok]
		all.objs <- all.objs.ok
		repeat{
			if(length(all.objs) == nr) break
			seed1 <- seed2+1
			seed2 <- seed1+ceiling((nr-length(all.objs))*1.1)-1
			clus <- makeCluster(n.core)
#			clusterEvalQ(cl = clus, expr = library(gamlss))
			clusterExport(cl = clus, varlist = c('inner.boot.ci.gamlss', 'wh'))
			erg <- clusterApplyLB(cl = clus, x = seed1:seed2, fun = inner.boot.ci.gamlss,
					data = data, n = n, orig.obj = orig.obj, xname = xname, xvalues = xvalues, p = p)
			stopCluster(cl = clus)				
			id.ok <- sapply(erg, function(x)ifelse(any(sapply(x, class) %in% "try-error"), F, T))
			all.objs.ok <- erg[id.ok]		
			all.objs <- c(all.objs, all.objs.ok)
			all.objs <- all.objs[1:min(c(nr, length(all.objs)))]
		}		
		for(id in 1:nr){
			for(i in quind){
				if(id == 1) rqu[[i]] <- matrix(nrow = length(xvalues), ncol = nr)
			rqu[[i]][,id] <- all.objs[[id]][[2]][,i+1]
			}
		}					
	}else{
		id <- 0
		while(id<nr){
			gobj <- NULL
			seed <- seed+1
			set.seed(seed)
			rdat <- data[sample(x = 1:n, size = n, replace = T),]					
			gobj <- try(update(orig.obj, data = rdat))
			# if fit was successful, set index and assign to result objects
			if(!"try-error" %in% class(gobj)){
				id <- id+1
				all.objs[[id]] <- gobj
				trqu <- withCallingHandlers(
					centiles.pred(obj = gobj, type = "centiles", xname = xname, xvalues = xvalues, cent = 100*p, data = rdat), 
					warning = wh)
				for(i in quind){
					if(id == 1) rqu[[i]] <- matrix(nrow = length(xvalues), ncol = nr)
					rqu[[i]][,id] <- trqu[,i+1]
				}
			}
			if(!is.null(status.freq)) if(id>0 & id%%status.freq == 0) {
				print(paste(id, " resample", ifelse(id>1, "s", ""), " ran.", sep = ""))
			}
		rm(rdat, envir = .GlobalEnv)
		}
	}
	names(rqu) <- paste("P", round(100*p, 1), sep = "") 
	cis <- matrix(nrow = length(xvalues), ncol = 2*length(p),
			dimnames = list(xvalues, paste("P", rep(round(100*p, 1), e = 2), rep(c("_LCL", "_UCL"), length(p)), sep = "")))
	for(i in quind){
		cis[,2*i-1] <- apply(rqu[[i]], 1, function(x){quantile(x, p = cils[1], type = qtype)})
		cis[,2*i] <- apply(rqu[[i]], 1, function(x){quantile(x, p = cils[2], type = qtype)})
	}	
	oqu <- withCallingHandlers(centiles.pred(obj = orig.obj, type = "centiles", xname = xname, xvalues = xvalues, cent = 100*p, data = data), 
				warning = wh)	
	colnames(oqu)[-1] <- paste("P", round(100*p, 1), sep = "")
	qoutind <- 1
	for(i in quind) qoutind <- c(qoutind, 2*i+length(quind), i+1, 2*i+1+length(quind))
	qout <- cbind(oqu, as.data.frame(cis))[,qoutind]
	t1 <- Sys.time()	
	t10 <- difftime(t1, t0)
	if(print.dur) print(paste("Duration of calculation:", round(t10), attr(t10, "units")))
	if(obj.out){
		return(list(Percentiles = qout, CIs = cis, resample_percentiles = rqu, GAMLSS_objects = all.objs))
	}else{
		return(list(Percentiles = qout, CIs = cis, resample_percentiles = rqu))
	}
}





#' Suppressing frequent warning about discrepancy between original and re-fit
#'
#' @export
#' @author  Peter Dilba
#' @name    Specific Warning Handling Function
#' @title   wh
#'
#' @param w   expression
#' @return    a list with tables with of quantiles and CIs of a fitted LMS model, for given x values and a table with resampling results
#'


wh <- function(w)
{
	if(any(grepl("discrepancy  between the original and the re-fit", w))) invokeRestart("muffleWarning")
}




#' internal function to enable multicore performance of cont_quantiles_ci.gamlss
#'
#' @export
#' @author  Peter Dilba
#' @name    Specific Warning Handling Function
#' @title   wh
#'
#' @param seed   seed argument passed from cont_quantiles_ci.gamlss()
#' @param data   data argument passed from cont_quantiles_ci.gamlss()
#' @param n   n argument passed from cont_quantiles_ci.gamlss()
#' @param orig.obj   originally fitted object, passed as 'obj' within cont_quantiles_ci.gamlss()
#' @param xname   xname argument passed from cont_quantiles_ci.gamlss()
#' @param xvalues   xvalues argument passed from cont_quantiles_ci.gamlss()
#' @param p   p argument passed from cont_quantiles_ci.gamlss()
#' @return    a list with a fitted LMS model and fitted quantiles as estimated by centiles.pred() if model is fitted without error, NULL otherwise
#'

inner.boot.ci.gamlss <- function(seed, data, n, orig.obj, xname, xvalues, p)
{
	gobj <- NULL
	seed <- seed+1
	set.seed(seed)
	# update gamlss object with resampled data
	rdat <- data[sample(x = 1:n, size = n, replace = T),]
	gobj <- try(update(obj=orig.obj, data=rdat))
	# if fit was successful, assign results
	if(!"try-error" %in% class(gobj)){
		trqu <- try(withCallingHandlers(
			centiles.pred(obj = gobj, type = "centiles", xname = xname, xvalues = xvalues, cent = 100*p, data=rdat), 
				warning = wh))
	}else{
		trqu <- NULL
	}
	return(list(gobj, trqu))
}



#' Report results of a LMS model depending on 'new' x-values
#'
#' @export
#' @author  Peter Dilba
#' @name    LMS Result Reporting Function
#' @title   lms.results
#'
#' @param obj   a gamlss object with only one covariate
#' @param data   data of the original fitted model
#' @param xname	  character, the name of the unique explanatory variable (it has to be the same as in the original fitted model)
#' @param xvalues   the new values for the explanatory variable where the prediction will take place
#' @param p   percentiles to be calculated
#' @param sds   SD-scores to be calculated
#' @param ci   logical, should CIs be calculated?
#' @param ...   further arguments to be passed
#' @return    table of LMS results for given 'new' x-values
#'

lms_results <- function(obj, data = NULL, xname, xvalues, p = c(.025, .5, .975), sds = c(-2, 2), ci = T, ...)
{
	if(ci){
		pctls.full <- cont_quantiles_ci(obj = obj, data = data, xname = xname, xvalues = xvalues, c(p, pnorm(sds)), ...)
		pctls <- pctls.full$Percentiles	
		if(length(sds)>0) colnames(pctls)[(2+3*length(p)):(1+3*length(c(p, sds)))] <-
			paste(rep(sds, e = 3), "SD", rep(c("", "_LCL", "_UCL"), length(sds)), sep = "")
	}else{
		pctls <- cont_quantiles(obj = obj, data = data, xname = xname, xvalues = xvalues,
			p = c(p, pnorm(sds)))
		if(length(sds)>0) colnames(pctls)[(2+length(p)):(1+length(c(p, sds)))] <- paste(sds, "SD", sep = "")
	}
	lms.params <- parameters(obj = obj, data = data, xname = xname, xvalues = xvalues)
	res.table <- merge(pctls, lms.params, by = colnames(pctls)[1])
	class(res.table) <- c("data.frame", "lms.res")
	return(res.table)
}



#' Simulate data depending on x-values [0, 80] with an early peak and Sinh-Arcsinh distribution in y-direction
#'
#' @export
#' @author  Peter Dilba
#' @name    Simulation function 1
#' @title   simu01
#'
#' @param x   numeric, ideally [0, 80] to represent subjects' age
#' @param return   "course", if just the course of the data should be returned; "sample", if new simulated data should be created; "quantile", if a 'true' quantile for a given x should be returned 
#' @param p   quantiles [0, 1] to be calculated
#' @return    numeric, vector of same length as x
#'

simu01 <- function(x, return, p)
{
	x_tilde <- 1000*(dchisq(x, df = 20)+dnorm(x, mean = 30, sd = 20)+3*dnorm(x, mean = 40, sd = 30)+2*dnorm(x, mean = 70, sd = 30))	
	if(return == "course") return(x_tilde)
	if(return == "sample")
	{
		y <- rSHASH(n = length(x_tilde), mu = x_tilde, sigma = 3*log2(x_tilde), nu = .01*(200-.75*x_tilde), tau = .8)
		y[y <= 0] <- runif(n = sum(y <= 0), min = .1, max = 5)		
	}
	if(return == "quantile")
	{
		y <- qSHASH(p = p, mu = x_tilde, sigma = 3*log2(x_tilde), nu = .01*(200-.75*x_tilde), tau = .8)
	}
	return(y)	
}



#' Simulate data depending on x-values [0, 80] with a steady decrase and Sinh-Arcsinh distribution in y-direction
#'
#' @export
#' @author  Peter Dilba
#' @name    Simulation function 2
#' @title   simu02
#'
#' @param x   numeric, ideally [0, 80] to represent subjects' age
#' @param return   "course", if just the course of the data should be returned; "sample", if new simulated data should be created; "quantile", if a 'true' quantile for a given x should be returned 
#' @param p   quantiles [0, 1] to be calculated
#' @return    numeric, vector of same length as x
#'

simu02 <- function(x, return, p)
{
	x_tilde <- 50+300*dexp(x, .12)-.1*x	
	if(return == "course") return(x_tilde)
	if(return == "sample")
	{
		y <- rSHASH(n = length(x_tilde), mu = x_tilde, sigma = 4*log10(x_tilde), nu = .007*(200-.75*x_tilde), tau = .7)
		y[y <= 0] <- runif(n = sum(y <= 0), min = .1, max = 5)	
	}
	if(return == "quantile")
	{
		y <- qSHASH(p = p, mu = x_tilde, sigma = 4*log10(x_tilde), nu = .007*(200-.75*x_tilde), tau = .7)
	}
	return(y)	
}



#' Simulate data depending on x-values [0, 80] with a cubic course and Johnsons' SU distribution in y-direction
#'
#' @export
#' @author  Peter Dilba
#' @name    Simulation function 3
#' @title   simu03
#'
#' @param x   numeric, ideally [0, 80] to represent subjects' age
#' @param return   "course", if just the course of the data should be returned; "sample", if new simulated data should be created; "quantile", if a 'true' quantile for a given x should be returned 
#' @param p   quantiles [0, 1] to be calculated
#' @param pmin   minimum of lower range to avoid extreme outliers, defined by quantile 
#' @param pmax   maximum of uniform sampling ranges [pmin, pmax] to resample extreme outliers
#' @return    numeric, vector of same length as x
#'

simu03 <- function(x, return, p, pmin = .0025, pmax = .005)
{	
	x_tilde <- 100+(-.015*(x)-.005*(x-35)^2+.00015*(x-30)^3)*3
	if(return == "course") return(x_tilde)
	d3s <- function(x) 5+(-.1*(x)-.005*(x-35)^2+.0001*(x-25)^3)*.4
	d3n <- function(x) .5+(-.1*(x)-.005*(x-35)^2+.0001*(x-40)^3)*.025
	d3t <- function(x) 1-.002*(x-30)
	if(return == "sample")
	{
		y <- rJSUo(n = length(x), mu = x_tilde, sigma = d3s(x), nu = d3n(x), tau = d3t(x)) 	
		qmin <- qJSUo(p = pmin, mu = x_tilde, sigma = d3s(x), nu = d3n(x), tau = d3t(x))
		if(any(y<qmin)){
			id0 <- which(y<qmin)
			for(i in seq_along(id0)){
				y[id0[i]] <- runif(n = 1,
					min = qJSUo(p = pmin, mu = x_tilde[id0], sigma = d3s(x[id0[i]]), nu = d3n(x[id0[i]]), tau = d3t(x[id0[i]])),
					max = qJSUo(p = pmax, mu = x_tilde[id0], sigma = d3s(x[id0[i]]), nu = d3n(x[id0[i]]), tau = d3t(x[id0[i]])))
			}	
		}
	}
	if(return == "quantile")
	{
		y <- qJSUo(p = p, mu = x_tilde, sigma = d3s(x), nu = d3n(x), tau = d3t(x))
	}
	return(y)	
	
}



#' Simulate data depending on x-values [0, 80] with a quadratic course and LNO distribution in y-direction
#'
#' @export
#' @author  Peter Dilba
#' @name    Simulation function 4
#' @title   simu04
#'
#' @param x   numeric, ideally [0, 80] to represent subjects' age
#' @param return   "course", if just the course of the data should be returned; "sample", if new simulated data should be created; "quantile", if a 'true' quantile for a given x should be returned 
#' @param p   quantiles [0, 1] to be calculated
#' @return    numeric, vector of same length as x
#'

simu04 <- function(x, return, p)
{
	x_tilde <- (-.05*x+.015*(x-43)^2)*8+500
	if(return == "course") return(x_tilde)
	d4s <- function(x) (-.05*x+.015*(x-43)^2)*.008+.17
	if(return == "sample")
	{
		y <- rLNO(n = length(x), mu = log(x_tilde), sigma = d4s(x), nu = .1) 
	}
	if(return == "quantile")
	{
		y <- qLNO(p = p, mu = log(x_tilde), sigma = d4s(x), nu = .1)
	}
	return(y)	
	
}



#' Simulate data depending on x-values [0, 80] with a linear increase and EGB2 distribution in y-direction
#'
#' @export
#' @author  Peter Dilba
#' @name    Simulation function 5
#' @title   simu05
#'
#' @param x   numeric, ideally [0, 80] to represent subjects' age
#' @param return   "course", if just the course of the data should be returned; "sample", if new simulated data should be created; "quantile", if a 'true' quantile for a given x should be returned 
#' @param p   quantiles [0, 1] to be calculated
#' @return    numeric, vector of same length as x
#'

simu05 <- function(x, return, p)
{
	x_tilde <- 50+x
	if(return == "course") return(x_tilde)
	d5s <- function(x) 3+.015*x
	d5n <- function(x) .9+.005*x
	d5t <- function(x) .2+.003*x 
	if(return == "sample")
	{
		y <- rEGB2(n = length(x), mu = x_tilde, sigma = d5s(x), nu = d5n(x), tau = d5t(x)) 
	}
	if(return == "quantile")
	{
		y <- qEGB2(p = p, mu = x_tilde, sigma = d5s(x), nu = d5n(x), tau = d5t(x))
	}
	return(y)	
	
}



#' Simulate data depending on x-values [0, 80] without slope and varying EGB2 distribution in y-direction
#'
#' @export
#' @author  Peter Dilba
#' @name    Simulation function 6
#' @title   simu06
#'
#' @param x   numeric, ideally [0, 80] to represent subjects' age
#' @param return   "course", if just the course of the data should be returned; "sample", if new simulated data should be created; "quantile", if a 'true' quantile for a given x should be returned 
#' @param p   quantiles [0, 1] to be calculated
#' @return    numeric, vector of same length as x
#'

simu06 <- function(x, return, p)
{
	x_tilde <- 100-(1+.0025*(x-30)^2)*log((1+.01*x)/.105)
	if(return == "course") return(x_tilde)
	d6s <- function(x) 1+.0025*(x-30)^2
	d6n <- function(x) 1+.01*x
	if(return == "sample")
	{
		y <- rEGB2(n = length(x), mu = x_tilde, sigma = d6s(x), nu = d6n(x), tau = .3)
	}
	if(return == "quantile")
	{
		y <- qEGB2(p = p, mu = x_tilde, sigma = d6s(x), nu = d6n(x), tau = .3)
	}
	return(y)	
	
}

